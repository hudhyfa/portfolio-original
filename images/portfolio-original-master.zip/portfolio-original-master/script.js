

let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.menubar');

menu.onclick = () => {
    console.log("click");
    menu.classList.toggle ('menu-x');
    navbar.classList.toggle ('open');
}